document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('dados');
    const commentInput = document.getElementById('comment');
    const comentariosDiv = document.getElementById('commentform');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const mensagemSucesso = document.getElementById('mensagemsucesso');
    const mensagemErro = document.getElementById('mensagemerro');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const commentText = commentInput.value;
   

        if (commentText.trim() !== '') {
            const novoComentario = document.createElement('p');
           
            comentariosDiv.appendChild(novoComentario);

            commentInput.value = '';
            nameInput.value = '';
            emailInput.value = '';

            // Exibe a mensagem de sucesso
            mensagemSucesso.style.display = 'block'; // Mostra a mensagem
            setTimeout(function() {
                mensagemSucesso.style.display = 'none'; // Oculta a mensagem após 3 segundos
            }, 3000);
        } else {
           mensagemErro.style.display = 'block'
           setTimeout(function(){
        mensagemErro.style.display = 'none';
           },3000);
        }
    });
});
